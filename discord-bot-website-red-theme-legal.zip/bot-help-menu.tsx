import Image from "next/image"
import { Heart } from "lucide-react"

export default function Component() {
  return (
    <div className="min-h-screen bg-gray-800 text-white p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 rounded-full overflow-hidden">
            <Image
              src="/placeholder.svg?height=48&width=48"
              alt="Walt Bot Avatar"
              width={48}
              height={48}
              className="w-full h-full object-cover"
            />
          </div>
          <div className="flex items-center gap-2">
            <span className="text-red-400 text-xl font-semibold">Walt</span>
            <span className="bg-blue-600 text-xs px-2 py-1 rounded text-white font-medium">BOT</span>
            <span className="text-gray-400 text-sm">Today at 1:56 PM</span>
          </div>
        </div>

        {/* Main Content */}
        <div className="bg-gray-700 rounded-lg p-6 border-l-4 border-red-500 relative">
          {/* Avatar on right */}
          <div className="absolute top-4 right-4 w-16 h-16 rounded-lg overflow-hidden">
            <Image
              src="/placeholder.svg?height=64&width=64"
              alt="Walt Bot Avatar"
              width={64}
              height={64}
              className="w-full h-full object-cover"
            />
          </div>

          <h1 className="text-xl font-bold mb-4">Walt - Help Menu</h1>

          <div className="mb-4 text-gray-300">
            <p>- Prefix for this server is -</p>
            <p>- Type .help {"<command | name>"} for more commands info.</p>
            <p className="mt-2">
              -{" "}
              <a href="#" className="text-blue-400 hover:underline">
                Invite Makima
              </a>{" "}
              |{" "}
              <a href="#" className="text-blue-400 hover:underline">
                Support Server
              </a>{" "}
              |{" "}
              <a href="#" className="text-blue-400 hover:underline">
                Vote Me
              </a>
            </p>
          </div>

          {/* Command Categories */}
          <div className="space-y-6">
            {/* Configuration */}
            <div>
              <h2 className="text-white font-semibold mb-2">• Configuration (9)</h2>
              <p className="text-gray-300 text-sm leading-relaxed">
                247, defaultvolume, dj-add, dj-list, dj-remove, dj-reset, dj-toggle, setup
              </p>
            </div>

            {/* Filters */}
            <div>
              <h2 className="text-white font-semibold mb-2">• Filters (25)</h2>
              <p className="text-gray-300 text-sm leading-relaxed">
                clear, 8d, soft, speed, karaoke, nightcore, pop, vaporwave, bass, party, earrape, equalizer, electronic,
                radio, tremolo, treblebass, vibrato, china, chipmunk, darthvader, daycore, doubletime, pitch, rate, slow
              </p>
            </div>

            {/* Music */}
            <div>
              <h2 className="text-white font-semibold mb-2">• Music (18)</h2>
              <p className="text-gray-300 text-sm leading-relaxed">
                autoplay, clear, join, leave, loop, lyric, nowplaying, pause, play, previous, queue, remove, resume,
                seek, shuffle, skip, stop, volume
              </p>
            </div>

            {/* Playlist */}
            <div>
              <h2 className="text-white font-semibold mb-2">• Playlist (7)</h2>
              <p className="text-gray-300 text-sm leading-relaxed">
                playlist-add, playlist-create, playlist-delete, playlist-info, playlist-list, playlist-play,
                playlist-save
              </p>
            </div>

            {/* Moderation */}
            <div>
              <h2 className="text-white font-semibold mb-2">• Moderation (13)</h2>
              <p className="text-gray-300 text-sm leading-relaxed">
                ban, banlist, kick, lock, lockall, timeout, purge, role, unban, unbanall, unlock, unlockall,
                remove-timeout
              </p>
            </div>

            {/* Utility */}
            <div>
              <h2 className="text-white font-semibold mb-2">• Utility (17)</h2>
              <p className="text-gray-300 text-sm leading-relaxed">
                about, afk, avatar, banner, boostcount, membercount, serverinfo, snipe, userinfo, checkvote, help,
                invite, ping, stats, uptime, support, report
              </p>
            </div>
          </div>

          {/* Footer */}
          <div className="mt-8 pt-4 border-t border-gray-600">
            <div className="flex items-center gap-2 text-gray-400 text-sm">
              <div className="w-6 h-6 rounded-full overflow-hidden">
                <Image
                  src="/placeholder.svg?height=24&width=24"
                  alt="Creator Avatar"
                  width={24}
                  height={24}
                  className="w-full h-full object-cover"
                />
              </div>
              <span>Made with</span>
              <Heart className="w-4 h-4 text-red-500 fill-current" />
              <span>by koushik7001</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
