import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { MessageCircle, HelpCircle, Bug, Star } from "lucide-react"

export default function SupportPage() {
  return (
    <div className="min-h-screen bg-gray-800 py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-white mb-4">Get Support</h1>
          <p className="text-xl text-gray-400">
            Need help with Walt? We're here to assist you with any questions or issues.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
          <Card className="bg-gray-700 border-gray-600 hover:border-red-500 transition-colors">
            <CardHeader>
              <CardTitle className="flex items-center gap-3 text-white">
                <MessageCircle className="w-6 h-6 text-red-400" />
                Discord Support Server
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-300 mb-4">
                Join our official Discord server for real-time support, updates, and community discussions.
              </p>
              <Button asChild className="w-full bg-blue-600 hover:bg-blue-700">
                <a href="#" target="_blank" rel="noopener noreferrer">
                  Join Support Server
                </a>
              </Button>
            </CardContent>
          </Card>

          <Card className="bg-gray-700 border-gray-600 hover:border-red-500 transition-colors">
            <CardHeader>
              <CardTitle className="flex items-center gap-3 text-white">
                <Star className="w-6 h-6 text-red-400" />
                Vote for Walt
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-300 mb-4">
                Support Walt by voting on Discord bot lists. It helps us grow and improve!
              </p>
              <Button asChild className="w-full bg-green-600 hover:bg-green-700">
                <a href="#" target="_blank" rel="noopener noreferrer">
                  Vote Now
                </a>
              </Button>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <Card className="bg-gray-700 border-gray-600 text-center">
            <CardContent className="p-6">
              <HelpCircle className="w-12 h-12 text-red-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-white mb-2">General Help</h3>
              <p className="text-gray-400 text-sm">Questions about commands, features, or setup</p>
            </CardContent>
          </Card>

          <Card className="bg-gray-700 border-gray-600 text-center">
            <CardContent className="p-6">
              <Bug className="w-12 h-12 text-red-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-white mb-2">Bug Reports</h3>
              <p className="text-gray-400 text-sm">Found a bug? Report it in our support server</p>
            </CardContent>
          </Card>

          <Card className="bg-gray-700 border-gray-600 text-center">
            <CardContent className="p-6">
              <Star className="w-12 h-12 text-red-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-white mb-2">Feature Requests</h3>
              <p className="text-gray-400 text-sm">Suggest new features and improvements</p>
            </CardContent>
          </Card>
        </div>

        <Card className="bg-gray-700 border-gray-600">
          <CardHeader>
            <CardTitle className="text-white">Frequently Asked Questions</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <h4 className="text-white font-semibold mb-2">How do I set up Walt in my server?</h4>
              <p className="text-gray-300">
                After inviting Walt, use the <code className="bg-gray-600 px-2 py-1 rounded">-setup</code> command to
                configure basic settings. Then use <code className="bg-gray-600 px-2 py-1 rounded">-help</code> to see
                all available commands.
              </p>
            </div>

            <div>
              <h4 className="text-white font-semibold mb-2">Why isn't Walt playing music?</h4>
              <p className="text-gray-300">
                Make sure Walt has permission to connect and speak in voice channels. Also ensure you're in a voice
                channel when using the <code className="bg-gray-600 px-2 py-1 rounded">-play</code> command.
              </p>
            </div>

            <div>
              <h4 className="text-white font-semibold mb-2">How do I use audio filters?</h4>
              <p className="text-gray-300">
                Walt has 25+ audio filters! Use commands like{" "}
                <code className="bg-gray-600 px-2 py-1 rounded">-nightcore</code>,
                <code className="bg-gray-600 px-2 py-1 rounded">-bass</code>, or{" "}
                <code className="bg-gray-600 px-2 py-1 rounded">-8d</code> while music is playing.
              </p>
            </div>

            <div>
              <h4 className="text-white font-semibold mb-2">Can I change the bot prefix?</h4>
              <p className="text-gray-300">
                Currently, Walt uses the default prefix <code className="bg-gray-600 px-2 py-1 rounded">-</code>. Custom
                prefixes may be added in future updates.
              </p>
            </div>
          </CardContent>
        </Card>

        <div className="text-center mt-12">
          <p className="text-gray-400 mb-6">Still need help? Don't hesitate to reach out!</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild className="bg-red-600 hover:bg-red-700">
              <a href="#" target="_blank" rel="noopener noreferrer">
                <MessageCircle className="w-4 h-4 mr-2" />
                Join Discord Server
              </a>
            </Button>
            <Button asChild variant="outline" className="border-gray-600 text-white hover:bg-gray-700">
              <Link href="/commands">
                <HelpCircle className="w-4 h-4 mr-2" />
                View Commands
              </Link>
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
