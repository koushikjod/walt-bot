import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Music, Shield, Settings, Zap, Users, Star } from "lucide-react"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-red-900">
      {/* Hero Section */}
      <section className="relative py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto text-center">
          <div className="flex justify-center mb-8">
            <div className="w-32 h-32 rounded-full overflow-hidden border-4 border-red-500">
              <Image
                src="/placeholder.svg?height=128&width=128"
                alt="Walt Bot Avatar"
                width={128}
                height={128}
                className="w-full h-full object-cover"
              />
            </div>
          </div>

          <h1 className="text-5xl md:text-7xl font-bold text-red-100 mb-6">
            Meet <span className="text-red-400">Walt</span>
          </h1>

          <p className="text-xl md:text-2xl text-gray-300 mb-8 max-w-3xl mx-auto">
            The ultimate Discord music bot with advanced audio filters, playlist management, and powerful moderation
            tools to enhance your server experience.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" className="bg-red-600 hover:bg-red-700 text-lg px-8 py-3">
              <Link href="/invite">Invite Walt to Your Server</Link>
            </Button>
            <Button
              asChild
              variant="outline"
              size="lg"
              className="text-lg px-8 py-3 border-gray-600 text-red-100 hover:bg-red-700"
            >
              <Link href="/commands">View Commands</Link>
            </Button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-16 max-w-4xl mx-auto">
            <div className="text-center">
              <div className="text-3xl font-bold text-red-400 mb-2">10,000+</div>
              <div className="text-red-300">Servers</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-red-400 mb-2">500K+</div>
              <div className="text-red-300">Users</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-red-400 mb-2">99.9%</div>
              <div className="text-red-300">Uptime</div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-red-950">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-red-100 mb-4">Powerful Features</h2>
            <p className="text-xl text-red-300">Everything you need for the perfect Discord experience</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="bg-red-900 border-red-700">
              <CardContent className="p-6 text-center">
                <Music className="w-12 h-12 text-red-400 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-red-100 mb-2">High-Quality Music</h3>
                <p className="text-red-300">
                  Stream music from multiple sources with crystal clear audio quality and minimal latency.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-red-900 border-red-700">
              <CardContent className="p-6 text-center">
                <Zap className="w-12 h-12 text-red-400 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-red-100 mb-2">25 Audio Filters</h3>
                <p className="text-red-300">
                  Transform your music with nightcore, bass boost, 8D, karaoke, and 20+ other filters.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-red-900 border-red-700">
              <CardContent className="p-6 text-center">
                <Settings className="w-12 h-12 text-red-400 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-red-100 mb-2">Easy Configuration</h3>
                <p className="text-red-300">
                  Simple setup with DJ roles, volume controls, and server-specific prefix customization.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-red-900 border-red-700">
              <CardContent className="p-6 text-center">
                <Shield className="w-12 h-12 text-red-400 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-red-100 mb-2">Moderation Tools</h3>
                <p className="text-red-300">
                  Keep your server safe with ban, kick, timeout, purge, and advanced moderation commands.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-red-900 border-red-700">
              <CardContent className="p-6 text-center">
                <Users className="w-12 h-12 text-red-400 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-red-100 mb-2">Playlist Management</h3>
                <p className="text-red-300">Create, save, and share custom playlists with your server members.</p>
              </CardContent>
            </Card>

            <Card className="bg-red-900 border-red-700">
              <CardContent className="p-6 text-center">
                <Star className="w-12 h-12 text-red-400 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-red-100 mb-2">Utility Commands</h3>
                <p className="text-red-300">
                  Server info, user avatars, uptime stats, and 15+ utility commands for server management.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl font-bold text-red-100 mb-4">Ready to Get Started?</h2>
          <p className="text-xl text-red-300 mb-8">
            Join thousands of servers already using Walt for their music and moderation needs.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" className="bg-red-600 hover:bg-red-700 text-lg px-8 py-3">
              <Link href="/invite">Add Walt to Discord</Link>
            </Button>
            <Button
              asChild
              variant="outline"
              size="lg"
              className="text-lg px-8 py-3 border-gray-600 text-red-100 hover:bg-red-700"
            >
              <Link href="/support">Join Support Server</Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}
