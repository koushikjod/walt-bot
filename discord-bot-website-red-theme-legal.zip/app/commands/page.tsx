import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Music, Settings, Shield, Zap, List, Wrench } from "lucide-react"

const commandCategories = [
  {
    name: "Configuration",
    icon: Settings,
    count: 9,
    color: "bg-blue-600",
    commands: ["247", "defaultvolume", "dj-add", "dj-list", "dj-remove", "dj-reset", "dj-toggle", "setup"],
  },
  {
    name: "Filters",
    icon: Zap,
    count: 25,
    color: "bg-purple-600",
    commands: [
      "clear",
      "8d",
      "soft",
      "speed",
      "karaoke",
      "nightcore",
      "pop",
      "vaporwave",
      "bass",
      "party",
      "earrape",
      "equalizer",
      "electronic",
      "radio",
      "tremolo",
      "treblebass",
      "vibrato",
      "china",
      "chipmunk",
      "darthvader",
      "daycore",
      "doubletime",
      "pitch",
      "rate",
      "slow",
    ],
  },
  {
    name: "Music",
    icon: Music,
    count: 18,
    color: "bg-red-600",
    commands: [
      "autoplay",
      "clear",
      "join",
      "leave",
      "loop",
      "lyric",
      "nowplaying",
      "pause",
      "play",
      "previous",
      "queue",
      "remove",
      "resume",
      "seek",
      "shuffle",
      "skip",
      "stop",
      "volume",
    ],
  },
  {
    name: "Playlist",
    icon: List,
    count: 7,
    color: "bg-green-600",
    commands: [
      "playlist-add",
      "playlist-create",
      "playlist-delete",
      "playlist-info",
      "playlist-list",
      "playlist-play",
      "playlist-save",
    ],
  },
  {
    name: "Moderation",
    icon: Shield,
    count: 13,
    color: "bg-orange-600",
    commands: [
      "ban",
      "banlist",
      "kick",
      "lock",
      "lockall",
      "timeout",
      "purge",
      "role",
      "unban",
      "unbanall",
      "unlock",
      "unlockall",
      "remove-timeout",
    ],
  },
  {
    name: "Utility",
    icon: Wrench,
    count: 17,
    color: "bg-cyan-600",
    commands: [
      "about",
      "afk",
      "avatar",
      "banner",
      "boostcount",
      "membercount",
      "serverinfo",
      "snipe",
      "userinfo",
      "checkvote",
      "help",
      "invite",
      "ping",
      "stats",
      "uptime",
      "support",
      "report",
    ],
  },
]

export default function CommandsPage() {
  return (
    <div className="min-h-screen bg-gray-800 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-white mb-4">Walt Commands</h1>
          <p className="text-xl text-gray-400 mb-6">
            Explore all {commandCategories.reduce((total, cat) => total + cat.count, 0)} commands available in Walt
          </p>
          <div className="bg-gray-700 rounded-lg p-4 max-w-2xl mx-auto">
            <p className="text-gray-300 mb-2">
              <strong>Server Prefix:</strong> <code className="bg-gray-600 px-2 py-1 rounded">-</code>
            </p>
            <p className="text-gray-300">
              Type <code className="bg-gray-600 px-2 py-1 rounded">-help &lt;command&gt;</code> for detailed command
              information
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {commandCategories.map((category) => {
            const IconComponent = category.icon
            return (
              <Card key={category.name} className="bg-gray-700 border-gray-600">
                <CardHeader>
                  <CardTitle className="flex items-center gap-3 text-white">
                    <div className={`p-2 rounded-lg ${category.color}`}>
                      <IconComponent className="w-6 h-6 text-white" />
                    </div>
                    {category.name}
                    <Badge variant="secondary" className="bg-gray-600 text-white">
                      {category.count}
                    </Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {category.commands.map((command) => (
                      <Badge
                        key={command}
                        variant="outline"
                        className="border-gray-500 text-gray-300 hover:bg-gray-600 cursor-pointer"
                      >
                        {command}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>

        <div className="mt-12 text-center">
          <div className="bg-gray-700 rounded-lg p-6 max-w-4xl mx-auto">
            <h3 className="text-xl font-semibold text-white mb-4">Need Help?</h3>
            <p className="text-gray-300 mb-4">
              Join our support server for assistance, feature requests, or to report bugs.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a href="#" className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg transition-colors">
                Support Server
              </a>
              <a href="#" className="bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded-lg transition-colors">
                Vote for Walt
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
