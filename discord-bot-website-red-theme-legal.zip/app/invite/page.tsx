import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { CheckCircle, ExternalLink, Shield, Music, Settings } from "lucide-react"

export default function InvitePage() {
  return (
    <div className="min-h-screen bg-gray-800 py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <div className="flex justify-center mb-6">
            <div className="w-24 h-24 rounded-full overflow-hidden border-4 border-red-500">
              <Image
                src="/placeholder.svg?height=96&width=96"
                alt="Walt Bot Avatar"
                width={96}
                height={96}
                className="w-full h-full object-cover"
              />
            </div>
          </div>
          <h1 className="text-4xl font-bold text-white mb-4">Invite Walt to Your Server</h1>
          <p className="text-xl text-gray-400">
            Add Walt to your Discord server and start enjoying high-quality music and powerful moderation tools.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
          <Card className="bg-gray-700 border-gray-600">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-white">
                <Music className="w-6 h-6 text-red-400" />
                Recommended Permissions
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center gap-2 text-gray-300">
                <CheckCircle className="w-5 h-5 text-green-400" />
                Connect & Speak in Voice Channels
              </div>
              <div className="flex items-center gap-2 text-gray-300">
                <CheckCircle className="w-5 h-5 text-green-400" />
                Send Messages & Embed Links
              </div>
              <div className="flex items-center gap-2 text-gray-300">
                <CheckCircle className="w-5 h-5 text-green-400" />
                Use External Emojis
              </div>
              <div className="flex items-center gap-2 text-gray-300">
                <CheckCircle className="w-5 h-5 text-green-400" />
                Add Reactions
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gray-700 border-gray-600">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-white">
                <Shield className="w-6 h-6 text-red-400" />
                Moderation Permissions
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center gap-2 text-gray-300">
                <CheckCircle className="w-5 h-5 text-green-400" />
                Ban & Kick Members
              </div>
              <div className="flex items-center gap-2 text-gray-300">
                <CheckCircle className="w-5 h-5 text-green-400" />
                Timeout Members
              </div>
              <div className="flex items-center gap-2 text-gray-300">
                <CheckCircle className="w-5 h-5 text-green-400" />
                Manage Messages
              </div>
              <div className="flex items-center gap-2 text-gray-300">
                <CheckCircle className="w-5 h-5 text-green-400" />
                Manage Roles
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="text-center mb-8">
          <Button asChild size="lg" className="bg-red-600 hover:bg-red-700 text-lg px-12 py-4">
            <a
              href="https://discord.com/api/oauth2/authorize?client_id=YOUR_BOT_ID&permissions=8&scope=bot%20applications.commands"
              target="_blank"
              rel="noopener noreferrer"
            >
              <ExternalLink className="w-5 h-5 mr-2" />
              Invite Walt Now
            </a>
          </Button>
        </div>

        <Card className="bg-gray-700 border-gray-600">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-white">
              <Settings className="w-6 h-6 text-red-400" />
              Getting Started
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-start gap-3">
              <div className="bg-red-600 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold">
                1
              </div>
              <div>
                <h4 className="text-white font-semibold">Invite Walt</h4>
                <p className="text-gray-400">Click the invite button above and select your server.</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="bg-red-600 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold">
                2
              </div>
              <div>
                <h4 className="text-white font-semibold">Run Setup</h4>
                <p className="text-gray-400">
                  Use <code className="bg-gray-600 px-2 py-1 rounded">-setup</code> to configure Walt for your server.
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="bg-red-600 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold">
                3
              </div>
              <div>
                <h4 className="text-white font-semibold">Start Playing Music</h4>
                <p className="text-gray-400">
                  Join a voice channel and use <code className="bg-gray-600 px-2 py-1 rounded">-play [song]</code> to
                  start!
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="text-center mt-8">
          <p className="text-gray-400 mb-4">Need help setting up Walt?</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild variant="outline" className="border-gray-600 text-white hover:bg-gray-700">
              <Link href="/support">Join Support Server</Link>
            </Button>
            <Button asChild variant="outline" className="border-gray-600 text-white hover:bg-gray-700">
              <Link href="/commands">View All Commands</Link>
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
