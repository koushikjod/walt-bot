export default function TermsOfServicePage() {
  return (
    <div className="min-h-screen bg-red-900 text-red-100 p-8">
      <h1 className="text-4xl font-bold mb-4">Terms of Service</h1>
      <p className="mb-2">
        By using our Discord bot, you agree to comply with Discord's Terms of Service and Community Guidelines.
      </p>
      <p className="mb-2">
        Abuse, spamming, or malicious usage of the bot may result in restrictions or bans from our services.
      </p>
      <p>
        We reserve the right to modify or discontinue the bot at any time, with or without notice.
      </p>
    </div>
  );
}