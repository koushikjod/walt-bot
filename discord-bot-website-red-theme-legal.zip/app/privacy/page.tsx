export default function PrivacyPolicyPage() {
  return (
    <div className="min-h-screen bg-red-900 text-red-100 p-8">
      <h1 className="text-4xl font-bold mb-4">Privacy Policy</h1>
      <p className="mb-2">
        Your privacy is important to us. We do not collect any personal information unless necessary for bot operation.
      </p>
      <p className="mb-2">
        Any data stored is limited to what is required to provide bot functionality and is never shared with third parties.
      </p>
      <p>
        By using our bot, you agree to this privacy policy. This policy may be updated at any time without notice.
      </p>
    </div>
  );
}