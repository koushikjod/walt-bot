"use client"

import Link from "next/link"
import Image from "next/image"
import { useState } from "react"
import { Menu, X } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <nav className="bg-red-950 border-b border-gray-800 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Link href="/" className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-full overflow-hidden">
                <Image
                  src="/placeholder.svg?height=40&width=40"
                  alt="Walt Bot"
                  width={40}
                  height={40}
                  className="w-full h-full object-cover"
                />
              </div>
              <span className="text-red-400 text-xl font-bold">Walt</span>
              <span className="bg-blue-600 text-xs px-2 py-1 rounded text-red-100 font-medium">BOT</span>
            </Link>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            <Link href="/" className="text-gray-300 hover:text-red-100 transition-colors">
              Home
            </Link>
            <Link href="/commands" className="text-gray-300 hover:text-red-100 transition-colors">
              Commands
            </Link>
            <Link href="/features" className="text-gray-300 hover:text-red-100 transition-colors">
              Features
            </Link>
            <Link href="/support" className="text-gray-300 hover:text-red-100 transition-colors">
              Support
            </Link>
            <Button asChild className="bg-red-600 hover:bg-red-700">
              <Link href="/invite">Invite Walt</Link>
            </Button>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden flex items-center">
            <button onClick={() => setIsOpen(!isOpen)} className="text-gray-300 hover:text-red-100">
              {isOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isOpen && (
          <div className="md:hidden">
            <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3 bg-red-900">
              <Link href="/" className="block px-3 py-2 text-gray-300 hover:text-red-100">
                Home
              </Link>
              <Link href="/commands" className="block px-3 py-2 text-gray-300 hover:text-red-100">
                Commands
              </Link>
              <Link href="/features" className="block px-3 py-2 text-gray-300 hover:text-red-100">
                Features
              </Link>
              <Link href="/support" className="block px-3 py-2 text-gray-300 hover:text-red-100">
                Support
              </Link>
              <Button asChild className="w-full mt-2 bg-red-600 hover:bg-red-700">
                <Link href="/invite">Invite Walt</Link>
              </Button>
            </div>
          </div>
        )}
      </div>
    </nav>
  )
}
