import Link from "next/link"
import Image from "next/image"
import { Heart, Github, MessageCircle } from "lucide-react"

export default function Footer() {
  return (
    <footer className="bg-red-950 border-t border-gray-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-12 h-12 rounded-full overflow-hidden">
                <Image
                  src="/placeholder.svg?height=48&width=48"
                  alt="Walt Bot"
                  width={48}
                  height={48}
                  className="w-full h-full object-cover"
                />
              </div>
              <span className="text-red-400 text-2xl font-bold">Walt</span>
            </div>
            <p className="text-red-300 mb-4 max-w-md">
              The ultimate Discord music bot with advanced filters, playlist management, and moderation tools. Enhance
              your server with high-quality music and powerful features.
            </p>
            <div className="flex items-center gap-2 text-red-300">
              <Heart className="w-4 h-4 text-red-500 fill-current" />
              <span>Made with love by koushik7001</span>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-red-100 font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/invite" className="text-red-300 hover:text-red-100 transition-colors">
                  Invite Bot
                </Link>
              </li>
              <li>
                <Link href="/commands" className="text-red-300 hover:text-red-100 transition-colors">
                  Commands
                </Link>
              </li>
              <li>
                <Link href="/features" className="text-red-300 hover:text-red-100 transition-colors">
                  Features
                </Link>
              </li>
              <li>
                <Link href="/support" className="text-red-300 hover:text-red-100 transition-colors">
                  Support
                </Link>
              </li>
            </ul>
          </div>

          {/* Support */}
          <div>
            <h3 className="text-red-100 font-semibold mb-4">Support</h3>
            <ul className="space-y-2">
              <li>
                <a href="#" className="text-red-300 hover:text-red-100 transition-colors flex items-center gap-2">
                  <MessageCircle className="w-4 h-4" />
                  Discord Server
                </a>
              </li>
              <li>
                <a href="#" className="text-red-300 hover:text-red-100 transition-colors flex items-center gap-2">
                  <Github className="w-4 h-4" />
                  GitHub
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-8 pt-8 text-center">
          <p className="text-red-300">© 2024 Walt Discord Bot. All rights reserved.</p>
        </div>
      </div>
    
      <div className="mt-4 text-sm text-red-300">
        <a href="/privacy" className="hover:underline mr-4">Privacy Policy</a>
        <a href="/terms" className="hover:underline">Terms of Service</a>
      </div>
    </footer>
  )
}
